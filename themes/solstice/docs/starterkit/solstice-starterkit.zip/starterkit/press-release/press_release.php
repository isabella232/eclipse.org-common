<?php
/**
 * *****************************************************************************
 * Copyright (c) 2017 Eclipse Foundation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * Eric Poirier (Eclipse Foundation) - Initial implementation
 * *****************************************************************************
 */

require_once ($_SERVER['DOCUMENT_ROOT'] . "/eclipse.org-common/system/app.class.php");
require_once ($_SERVER['DOCUMENT_ROOT'] . "/eclipse.org-common/system/nav.class.php");

$App = new App();
$Nav = new Nav();
$Theme = $App->getThemeClass();

// Shared variables/configs for all pages of your website.
require_once ('_projectCommon.php');

$pageTitle = "Eclipse Press Release";

$Theme->setPageAuthor('Eclipse Foundation');
$Theme->setPageKeywords('Add maximal 20 keywords and seperate them from each other by a comma en a space.');
$Theme->setPageTitle($pageTitle);
$Theme->setNav($Nav);

ob_start();

// Insert content here
?>

<div id="maincontent">
  <div id="midcolumn">
    <h1><?php print $pageTitle; ?></h1>

    <!-- Replace this text with your content -->

    <ul>
      <li>Download and unzip the starterkit file</li>
      <li>Move the php file in /org/press-release directory</li>
      <li>Edit the content</li>
    </ul>
  </div>

  <!-- remove the entire <div> tag to omit the right column!  -->
  <div id="rightcolumn">
    <div class="sideitem">
      <h6>Related Links</h6>
      <ul>
        <li><a target="_blank" href="https://eclipse.org">Home</a></li>
      </ul>
    </div>
  </div>
</div>

<?php
// End of content

$html = ob_get_clean();
$Theme->setHtml($html);
$Theme->generatePage();